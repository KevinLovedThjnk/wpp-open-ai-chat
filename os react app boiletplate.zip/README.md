# React micro-app boilerplate - WPP Open Platform

For a quickstart and more details on our React boilerplate, head over to the [WPP Open Developer Docs](https://developers.os.wpp.com/docs/developer-guide/developing-products/product-boilerplates/react).
